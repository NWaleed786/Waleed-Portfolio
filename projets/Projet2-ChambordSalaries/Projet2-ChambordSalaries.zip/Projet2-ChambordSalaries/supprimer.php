<?php
declare(strict_types=1);
require_once __DIR__ . '/connexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: listeSalaries.php'); exit;
}
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
if ($id && $id > 0) {
    $stmt = $conn->prepare('DELETE FROM salaries WHERE id = ?');
    $stmt->execute([$id]);
}
header('Location: listeSalaries.php'); exit;
