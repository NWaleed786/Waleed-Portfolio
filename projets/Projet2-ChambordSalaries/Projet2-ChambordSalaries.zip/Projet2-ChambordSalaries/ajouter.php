<?php
declare(strict_types=1);
require_once __DIR__ . '/fonctions.php';

$errors = [];
$data = ['nom'=>'','prenom'=>'','date_naissance'=>'','date_embauche'=>'','salaire'=>'','service'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$errors, $clean] = validerSalarie($_POST);
    $data = ['nom'=>$clean['nom'],'prenom'=>$clean['prenom'],'date_naissance'=>$clean['naissance'],'date_embauche'=>$clean['embauche'],'salaire'=>$clean['salaire'],'service'=>$clean['service']];
    if (!$errors) {
        $stmt = $conn->prepare('INSERT INTO salaries (nom, prenom, date_naissance, date_embauche, salaire, service) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([$clean['nom'], $clean['prenom'], $clean['naissance'], $clean['embauche'], $clean['salaire'], $clean['service']]);
        header('Location: listeSalaries.php'); exit;
    }
}
require __DIR__ . '/header.html';
?>
<div class="container pb-4">
    <div class="card p-4 mx-auto" style="max-width: 700px">
        <h1 class="h3 mb-4">Ajouter un salarié</h1>
        <?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post" novalidate>
            <div class="row g-3">
                <div class="col-md-6"><label class="form-label">Nom</label><input type="text" name="nom" class="form-control" maxlength="100" value="<?= e($data['nom']) ?>" required></div>
                <div class="col-md-6"><label class="form-label">Prénom</label><input type="text" name="prenom" class="form-control" maxlength="50" value="<?= e($data['prenom']) ?>" required></div>
                <div class="col-md-6"><label class="form-label">Date de naissance</label><input type="date" name="date_naissance" class="form-control" value="<?= e($data['date_naissance']) ?>" required></div>
                <div class="col-md-6"><label class="form-label">Date d'embauche</label><input type="date" name="date_embauche" class="form-control" value="<?= e($data['date_embauche']) ?>" required></div>
                <div class="col-md-6"><label class="form-label">Salaire</label><input type="number" name="salaire" class="form-control" min="0" max="999999" step="0.01" value="<?= e($data['salaire']) ?>" required></div>
                <div class="col-md-6"><label class="form-label">Service</label><input type="text" name="service" class="form-control" maxlength="50" value="<?= e($data['service']) ?>" required></div>
            </div>
            <div class="mt-4"><button type="submit" class="btn btn-success">Enregistrer</button> <a href="listeSalaries.php" class="btn btn-secondary">Annuler</a></div>
        </form>
    </div>
</div>
<?php require __DIR__ . '/footer.html'; ?>
