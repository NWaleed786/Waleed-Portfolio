<?php
declare(strict_types=1);

$host = 'localhost';
$dbname = getenv('CHAMBORD_DB_NAME') ?: 'chambord';
$user = getenv('CHAMBORD_DB_USER') ?: 'chambord_user';
$pass = getenv('CHAMBORD_DB_PASSWORD') ?: '';

try {
    $conn = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('Impossible de se connecter à la base de données. Vérifiez la configuration de connexion et que MySQL est démarré.');
}
