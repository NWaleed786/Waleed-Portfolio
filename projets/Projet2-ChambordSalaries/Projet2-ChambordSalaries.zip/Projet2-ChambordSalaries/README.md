# Projet Chambord

Application PHP de gestion des salaries avec MySQL/MariaDB.

L'application permet de :

- consulter la liste des salaries ;
- ajouter un salarie ;
- modifier un salarie ;
- supprimer un salarie ;
- afficher des statistiques par salaire et par service.

## 1. Prerequis

- PHP 8.0 ou une version plus recente ;
- Apache (XAMPP sous Windows ou Apache HTTP Server sous Linux) ;
- MySQL ou MariaDB ;
- un navigateur web.

Les commandes ci-dessous utilisent le nom de base `chambord`, l'utilisateur `chambord_user` et un mot de passe vide pour une installation locale uniquement. Pour un serveur accessible par d'autres personnes, utilisez un mot de passe et des variables d'environnement.

## 2. Installation sous Windows avec XAMPP

### 2.1 Installer XAMPP

1. Telecharger XAMPP depuis <https://www.apachefriends.org/>.
2. Installer au minimum **Apache**, **MySQL** et **PHP**.
3. Ouvrir le **XAMPP Control Panel**.
4. Cliquer sur **Start** pour Apache et MySQL.

Verification dans PowerShell :

```powershell
C:\xampp\php\php.exe --version
C:\xampp\mysql\bin\mysql.exe --version
Test-NetConnection localhost -Port 80
Test-NetConnection localhost -Port 3306
```

### 2.2 Copier le projet dans Apache

Copier le dossier du projet dans `C:\xampp\htdocs\Projet_Chambord`.

Depuis PowerShell :

```powershell
New-Item -ItemType Directory -Force C:\xampp\htdocs\Projet_Chambord
Copy-Item -Path .\* -Destination C:\xampp\htdocs\Projet_Chambord -Recurse -Force
Set-Location C:\xampp\htdocs\Projet_Chambord
```

Si le projet se trouve deja dans ce dossier, cette etape est inutile.

### 2.3 Creer la base et l'utilisateur

Ouvrir PowerShell ou l'invite de commandes :

```powershell
Set-Location C:\xampp\mysql\bin
.\mysql.exe -u root
```

Dans l'invite MariaDB/MySQL, executer :

```sql
CREATE DATABASE IF NOT EXISTS chambord CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
CREATE USER IF NOT EXISTS 'chambord_user'@'localhost' IDENTIFIED BY '';
GRANT ALL PRIVILEGES ON chambord.* TO 'chambord_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

Importer la table et les donnees depuis le dossier du projet :

```powershell
Set-Location C:\xampp\htdocs\Projet_Chambord
Get-Content .\salaries.sql -Raw | C:\xampp\mysql\bin\mysql.exe -u root chambord
```

Verifier l'import :

```powershell
C:\xampp\mysql\bin\mysql.exe -u chambord_user chambord -e "SELECT COUNT(*) AS total FROM salaries;"
```

Le resultat attendu est `20`.

### 2.4 Ouvrir le site

Dans un navigateur :

```text
http://localhost/Projet_Chambord/listeSalaries.php
```

### 2.5 Alternative : serveur PHP de developpement

Cette methode ne necessite pas Apache :

```powershell
Set-Location C:\xampp\htdocs\Projet_Chambord
C:\xampp\php\php.exe -S localhost:8000 -t .
```

Puis ouvrir <http://localhost:8000/listeSalaries.php>.

## 3. Installation sous Linux (Ubuntu/Debian)

### 3.1 Installer Apache, PHP et MariaDB

```bash
sudo apt update
sudo apt install -y apache2 mariadb-server php libapache2-mod-php php-mysql
sudo systemctl enable --now apache2
sudo systemctl enable --now mariadb
```

Verifier les services :

```bash
systemctl is-active apache2
systemctl is-active mariadb
php --version
mariadb --version
```

### 3.2 Copier le projet dans Apache

Depuis le dossier du projet :

```bash
sudo mkdir -p /var/www/html/Projet_Chambord
sudo cp -R ./* /var/www/html/Projet_Chambord/
sudo chown -R www-data:www-data /var/www/html/Projet_Chambord
sudo find /var/www/html/Projet_Chambord -type d -exec chmod 755 {} \;
sudo find /var/www/html/Projet_Chambord -type f -exec chmod 644 {} \;
```

### 3.3 Creer la base et l'utilisateur

```bash
sudo mariadb
```

Dans l'invite MariaDB :

```sql
CREATE DATABASE IF NOT EXISTS chambord CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
CREATE USER IF NOT EXISTS 'chambord_user'@'localhost' IDENTIFIED BY '';
GRANT ALL PRIVILEGES ON chambord.* TO 'chambord_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

Importer les tables et les donnees :

```bash
sudo mariadb chambord < /var/www/html/Projet_Chambord/salaries.sql
sudo mariadb -u chambord_user chambord -e "SELECT COUNT(*) AS total FROM salaries;"
```

Le resultat attendu est `20`.

### 3.4 Activer PHP et redemarrer Apache

```bash
sudo a2enmod php*
sudo systemctl restart apache2
```

Si `a2enmod php*` ne trouve aucun module, afficher les modules disponibles puis activer le module PHP installe :

```bash
ls /etc/apache2/mods-available/php*.load
sudo a2enmod php8.2
sudo systemctl restart apache2
```

Adaptez `php8.2` a la version affichee par `php --version`.

### 3.5 Ouvrir le site

Dans un navigateur :

```text
http://localhost/Projet_Chambord/listeSalaries.php
```

## 4. Configuration de la connexion

Le fichier `connexion.php` lit les variables suivantes :

- `CHAMBORD_DB_NAME` ;
- `CHAMBORD_DB_USER` ;
- `CHAMBORD_DB_PASSWORD`.

Par defaut, le projet utilise `chambord`, `chambord_user` et un mot de passe vide pour faciliter une installation locale. Pour definir une configuration personnalisee dans PowerShell :

```powershell
$env:CHAMBORD_DB_NAME = 'chambord'
$env:CHAMBORD_DB_USER = 'chambord_user'
$env:CHAMBORD_DB_PASSWORD = 'mot_de_passe_local'
```

Dans Linux avant de lancer le serveur PHP :

```bash
export CHAMBORD_DB_NAME=chambord
export CHAMBORD_DB_USER=chambord_user
export CHAMBORD_DB_PASSWORD='mot_de_passe_local'
```

Dans ce cas, le mot de passe de l'utilisateur MariaDB doit etre defini avec la meme valeur :

```sql
ALTER USER 'chambord_user'@'localhost' IDENTIFIED BY 'mot_de_passe_local';
FLUSH PRIVILEGES;
```

Ne committez jamais un vrai mot de passe dans le code ou dans le README.

## 5. Depannage

### Apache ne demarre pas sous Windows

Le port 80 peut etre utilise par IIS ou un autre logiciel. Dans XAMPP, modifiez `httpd.conf` et remplacez `Listen 80` par `Listen 8080`, puis utilisez :

```text
http://localhost:8080/Projet_Chambord/listeSalaries.php
```

### Erreur de connexion a MySQL/MariaDB

Verifier que le service est demarre, que la base existe et que l'utilisateur dispose des droits :

```bash
sudo systemctl status mariadb
```

Sous Windows :

```powershell
Get-Process mysqld -ErrorAction SilentlyContinue
Test-NetConnection localhost -Port 3306
```

### La table `salaries` n'existe pas

Relancer l'import SQL :

```bash
sudo mariadb chambord < /var/www/html/Projet_Chambord/salaries.sql
```

Sous Windows :

```powershell
Get-Content .\salaries.sql -Raw | C:\xampp\mysql\bin\mysql.exe -u root chambord
```


GitHub demande une authentification. Utilisez un Personal Access Token a la place d'un mot de passe GitHub quand cela est demande en HTTPS.

## 7. Structure principale

```text
ajouter.php          Formulaire et traitement d'ajout
connexion.php        Connexion PDO a MySQL/MariaDB
fonctions.php        Fonctions metier et requetes SQL
listeSalaries.php    Page principale et statistiques
modifier.php         Modification d'un salarie
supprimer.php        Suppression d'un salarie
salaries.sql         Structure et donnees initiales
header.html           En-tete HTML
footer.html           Pied de page
styles.css            Styles personnalises
```
