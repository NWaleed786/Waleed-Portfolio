<?php
declare(strict_types=1);
require_once __DIR__ . '/fonctions.php';
$salaries = getSalaries();
require __DIR__ . '/header.html';
?>
<div class="container pb-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h1 class="h3 mb-0">Liste des salariés</h1>
        <a href="ajouter.php" class="btn btn-success">+ Ajouter un salarié</a>
    </div>
    <div class="card p-3 mb-4">
        <div class="table-responsive">
            <table class="table table-striped table-bordered mb-0">
                <thead class="table-dark"><tr><th>ID</th><th>Nom</th><th>Prénom</th><th>Date naissance</th><th>Date embauche</th><th>Salaire</th><th>Service</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if (!$salaries): ?><tr><td colspan="8" class="text-center">Aucun salarié.</td></tr>
                <?php else: foreach ($salaries as $s): ?><tr>
                    <td><?= (int)$s['id'] ?></td><td><?= e($s['nom']) ?></td><td><?= e($s['prenom']) ?></td><td><?= e($s['date_naissance']) ?></td><td><?= e($s['date_embauche']) ?></td>
                    <td><?= number_format((float)$s['salaire'], 2, ',', ' ') ?> €</td><td><?= e($s['service']) ?></td>
                    <td class="actions"><a href="modifier.php?id=<?= (int)$s['id'] ?>" class="btn btn-primary btn-sm">Modifier</a>
                        <form method="post" action="supprimer.php" class="d-inline" onsubmit="return confirm('Voulez-vous vraiment supprimer ce salarié ?');"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button type="submit" class="btn btn-danger btn-sm">Supprimer</button></form>
                    </td>
                </tr><?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <h2 class="h4 mb-3">Statistiques</h2>
    <div class="row g-3 mb-4">
        <div class="col-sm-6 col-lg-3"><div class="card p-3"><div class="text-muted">Nombre total</div><div class="fs-3 fw-bold"><?= getNombreSalaries() ?></div></div></div>
        <div class="col-sm-6 col-lg-3"><div class="card p-3"><div class="text-muted">Salaire moyen</div><div class="fs-3 fw-bold"><?= number_format(getSalaireMoyen(), 2, ',', ' ') ?> €</div></div></div>
        <div class="col-sm-6 col-lg-3"><div class="card p-3"><div class="text-muted">Salaire maximum</div><div class="fs-3 fw-bold"><?= number_format(getSalaireMax(), 2, ',', ' ') ?> €</div></div></div>
        <div class="col-sm-6 col-lg-3"><div class="card p-3"><div class="text-muted">Salaire minimum</div><div class="fs-3 fw-bold"><?= number_format(getSalaireMin(), 2, ',', ' ') ?> €</div></div></div>
    </div>
    <div class="card p-3"><h3 class="h5">Nombre de salariés par service</h3><ul class="mb-0"><?php foreach (getNombreParService() as $service): ?><li><?= e($service['service']) ?> : <?= (int)$service['total'] ?></li><?php endforeach; ?></ul></div>
</div>
<?php require __DIR__ . '/footer.html'; ?>
