<?php
declare(strict_types=1);

require_once __DIR__ . '/connexion.php';

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function longueurTexte(string $value): int {
    preg_match_all('/./us', $value, $matches);
    return count($matches[0]);
}

function getSalaries(): array {
    global $conn;
    return $conn->query('SELECT * FROM salaries ORDER BY id')->fetchAll();
}

function getNombreSalaries(): int {
    global $conn;
    return (int) $conn->query('SELECT COUNT(*) FROM salaries')->fetchColumn();
}

function getSalaireMoyen(): float {
    global $conn;
    $value = $conn->query('SELECT AVG(salaire) FROM salaries')->fetchColumn();
    return round((float) $value, 2);
}

function getSalaireMax(): float {
    global $conn;
    return (float) ($conn->query('SELECT MAX(salaire) FROM salaries')->fetchColumn() ?? 0);
}

function getSalaireMin(): float {
    global $conn;
    return (float) ($conn->query('SELECT MIN(salaire) FROM salaries')->fetchColumn() ?? 0);
}

function getNombreParService(): array {
    global $conn;
    return $conn->query('SELECT service, COUNT(*) AS total FROM salaries GROUP BY service ORDER BY service')->fetchAll();
}

function getSalarieById(int $id): ?array {
    global $conn;
    $stmt = $conn->prepare('SELECT * FROM salaries WHERE id = ?');
    $stmt->execute([$id]);
    $salarie = $stmt->fetch();
    return $salarie ?: null;
}

function validerSalarie(array $data): array {
    $errors = [];
    $nom = trim((string)($data['nom'] ?? ''));
    $prenom = trim((string)($data['prenom'] ?? ''));
    $naissance = (string)($data['date_naissance'] ?? '');
    $embauche = (string)($data['date_embauche'] ?? '');
    $salaire = (string)($data['salaire'] ?? '');
    $service = trim((string)($data['service'] ?? ''));

    if ($nom === '' || longueurTexte($nom) > 100) $errors[] = 'Le nom est obligatoire (100 caractères maximum).';
    if ($prenom === '' || longueurTexte($prenom) > 50) $errors[] = 'Le prénom est obligatoire (50 caractères maximum).';
    if (!DateTime::createFromFormat('!Y-m-d', $naissance) || DateTime::createFromFormat('!Y-m-d', $naissance)->format('Y-m-d') !== $naissance) $errors[] = 'La date de naissance est invalide.';
    if (!DateTime::createFromFormat('!Y-m-d', $embauche) || DateTime::createFromFormat('!Y-m-d', $embauche)->format('Y-m-d') !== $embauche) $errors[] = "La date d'embauche est invalide.";
    if ($naissance !== '' && $embauche !== '' && $naissance > $embauche) $errors[] = "La date d'embauche doit être postérieure à la date de naissance.";
    if ($salaire === '' || !is_numeric($salaire) || (float)$salaire < 0 || (float)$salaire > 999999) $errors[] = 'Le salaire doit être un nombre positif inférieur à 1 000 000.';
    if ($service === '' || longueurTexte($service) > 50) $errors[] = 'Le service est obligatoire (50 caractères maximum).';

    return [$errors, compact('nom', 'prenom', 'naissance', 'embauche', 'salaire', 'service')];
}

